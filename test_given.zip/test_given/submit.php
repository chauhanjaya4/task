<?php
include'config/Database.php';
if(isset($_POST['submit']))
{
    $n=$_POST['name'];
    $e=$_POST['email'];
    $sub=$_POST['subject'];
    $result="insert into employee(`name`,`email`,`subject`) values('$name','$email','$subject')";
    $sql=mysqli_query($result,$con);
    if($sql==true)
    {
        echo"data inserted successfully";
    }
    else{
        echo"error inserting data";
    }

}



?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script src="aj.js"></script>
</head>
<body>
    
<form action="" method="POST" enctype="multipart/form-data">
    <input type="text" name="name"value="" id="name" placeholder="name"/>
    <input type="email" value="" name="email" id="email" placeholder="email"/>
    <select name="" id="" name="subject">
        <input type="radio" value="" placeholder="hindi" name="hindi">
        <input type="radio" value="" placeholder="english" name="english">
        <input type="radio" name="" id="" placeholder="maths" name="maths">
    </select>

    <button type="submit" name="submit">Submit</button>
</form>
<?php
include'config/Database.php';
if(isset($_POST['display']))
{
    
    $result="select *from employee ";
    $sql=mysqli_query($result,$con);
    if(mysqli_num_rows>0)
    {
    $row=mysqli_fetch_array_assoc($sql,$con);
    }
    
    {
        echo"data inserted successfully";
    }
    else{
        echo"error inserting data";
    }

}



?>
</body>
</html>